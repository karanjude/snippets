Karan Singh
5577894215
karans@usc.edu
